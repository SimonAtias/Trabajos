import java.util.ArrayList;

public class Fecha {

    // Atributos

    private int dia;
    private int mes;
    private int anio;

    // Constructor

    Fecha(int diaX, int mesX, int anioX){
        this.dia=diaX;
        this.anio=anioX;
        this.mes=mesX;
    }

    // Metodos

    public int getAnio() {
        return this.anio;
    }

    public int getDia() {
        return this.dia;
    }

    public int getMes() {
        return this.mes;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    // Metodo para returonar true si dos fechas son diferentes (this.fecha y fechaAux)
    public boolean esDifA(Fecha fechaAux){
        if(this.dia != fechaAux.getDia() || this.mes != fechaAux.getMes() || this.anio != fechaAux.getAnio()){
            return true;
        }
        return false;
    }

    // La logica de este metodo es casi la misma que agregarDias: Se tienen las condiciones o "IFs" para cada fecha y se mantiene un contador que cuenta los dias que hay entre dos fechas
    // distintas, la de entrada y la de salida.
    public int getCantDias(Fecha fechaSalida){  //  Metodo para conseguir la cantidad de dias entre dos fechas.

        Fecha fecha1 = new Fecha(this.dia, this.mes, this.anio);
        Fecha fecha2;
        fecha2=fechaSalida;

        int cantDias=1;

        while(fecha1.esDifA(fecha2)) {
            if (fecha1.getMes() == 1 || fecha1.getMes() == 3 || fecha1.getMes() == 5 || fecha1.getMes() == 7 || fecha1.getMes() == 8 || fecha1.getMes() == 10 || fecha1.getMes() == 12) {
                if (fecha1.getDia() == 31) {
                    if (fecha1.getMes() == 12) {
                        fecha1.setMes(1);
                        fecha1.setDia(1);
                        fecha1.setAnio(fecha1.getAnio()+1);
                        cantDias++;
                    }
                    else {
                        fecha1.setMes(fecha1.getMes()+1);
                        fecha1.setDia(1);
                        cantDias++;
                    }
                }
                else {
                    fecha1.setDia(fecha1.getDia()+1);
                    cantDias++;
                }
            }
            else if ((fecha1.getMes() == 4 || fecha1.getMes() == 6 || fecha1.getMes() == 9 || fecha1.getMes() == 11)) {
                if(fecha1.getDia()==30){
                    fecha1.setMes(fecha1.getMes()+1);
                    fecha1.setDia(1);
                    cantDias++;
                }
                else{
                    fecha1.setDia(fecha1.getDia()+1);
                    cantDias++;
                }
            }
            else{
                if(fecha1.getDia()==28  &&  fecha1.getAnio() % 4  !=  0 || fecha1.getDia()==29  &&  fecha1.getAnio() % 4  ==  0){
                    fecha1.setDia(1);
                    fecha1.setMes(fecha1.getMes()+1);
                    cantDias++;
                }
            }
        }
        return cantDias;
    }

}

