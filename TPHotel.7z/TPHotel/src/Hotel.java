import java.util.ArrayList;

public class Hotel {

    private ArrayList<Persona> Huesped = new ArrayList<Persona>();
    private ArrayList<Habitacion> Habitaciones = new ArrayList<Habitacion>();

    // Saca el indice de un arreglo de clientes de aquella persona que tiene mas hospedajes
    public int sacarIndiceDePersonaMasHospedajes(ArrayList<Persona> gente){
        int i=1;
        int indice = 0;
        int mayor=gente.get(0).getVecesHospedado();
        while(i<gente.size()){
            if(gente.get(i).getVecesHospedado()>mayor){
                mayor = gente.get(i).getVecesHospedado();
                indice=i;
            }
            i++;
        }
        return indice;
    }

    // Saca el indice de la habitacion con mas solicitudes de un arreglo de Habitaciones
    public int sacarIndiceDeLaHabMasSoli(){
        ArrayList<Habitacion> habitaciones= this.Habitaciones;
        int i=1;
        int indice = 0;
        int mayor=habitaciones.get(0).getSolicitudes();
        while(i<habitaciones.size()){
            if(habitaciones.get(i).getSolicitudes()>mayor){
                mayor = habitaciones.get(i).getSolicitudes();
                indice=i;
            }
            i++;
        }
        return indice;
    }

    //La logica de los ultimos dos metodos es declarar al primero como el mayor y luego ir recorriendo todos las posiciones hasta encontrar otro mayor.


    // Agrega clientes al arreglo de clientes del hotel. La razon por la que puse huespedes en Hotel y huespedes en Habitacion es porque quiero tener registro de los antiguos clientes
    // y tener el contador de las veces que se hospedaron.
    public void addClientes(Persona clienteEquis) {
        this.Huesped.add(clienteEquis);
    }

    public void addHabitacion(Habitacion habitacionEquis) {
        this.Habitaciones.add(habitacionEquis);
    }

    public void masFrecuentes(){                                                                  // Metodo para sacar a los Huespedes mas frecuentes: Crea un arreglo en el que obtiene todos los huespedes y por la
        ArrayList<Persona> frecuentes= new ArrayList<>();                                         // variable vecesHospedado se obtienen los DNIs que tienen los 2 mas hospedados huespedes.  La logica es: se  busca
        ArrayList<Persona> huespedes = (ArrayList<Persona>) this.Huesped.clone();                 // el Indice del mayor, se lo saca del arreglo en donde estan todos y se pone en uno nuevo para despues mostrarlo
        int i=0;
        while(i<2){
            int IndiceMayor=sacarIndiceDePersonaMasHospedajes(huespedes);
            frecuentes.add(huespedes.get(IndiceMayor));
            huespedes.get(IndiceMayor).printDNIs();
            huespedes.remove(IndiceMayor);
            i++;
        }
    }

    public void masSolicitadas(){                                                                  //imprime la 5 habitaciones mas solicitadas. Usa la misma logica que el de los huespedes que mas frecuentan el hotel.
        ArrayList<Habitacion> habitaciones= this.Habitaciones;
        ArrayList<Habitacion> habitacionesMasSolicitadas= new ArrayList<Habitacion>();
        int i=0;
        while(i<5){
            int IndiceMayor=this.sacarIndiceDeLaHabMasSoli();
            habitacionesMasSolicitadas.add(habitaciones.get(IndiceMayor));
            habitaciones.remove(IndiceMayor);
            habitaciones.get(IndiceMayor).printNumeroHab();
            i++;
        }
    }


    // Recorre todas las habitaciones del arreglo de habitaciones e immprime aquellas que tienen Habitacion.ocupada=true
    public void habOcupadas(){
        int i=0;
        System.out.println("Las habitaciones no disponibles son:");
        while(i<this.Habitaciones.size()){
            if(this.Habitaciones.get(i).getOcupada()){
                System.out.println(Habitaciones.get(i).getNumero());
            }
            i++;
        }
    }


    // Imprime las habitaciones disponibles. Lo opuesto al metodo anterior
    public void habDisponibles(){
        int i=0;
        System.out.println("Las habitaciones disponibles son:");
        while(i<this.Habitaciones.size()){
            if(!this.Habitaciones.get(i).getOcupada()){
                System.out.println(Habitaciones.get(i).getNumero());
            }
            i++;
        }
    }


    // Consigue la cantidad de dias y lo guarda en una variable. Con eso, lo multiplica al precio ed la habitacion y lo hace por cada habitacion. Al final de la iteracion, suma a
    // "monto" cada cuenta, acumulando el dinero que se gana. Ademas, hay dos posibles sumas al monto, la de estadia prolongada y la de la estadia normal.
    public int getIngresoTotal(){
        int ingreso=0;
        int i=0;
        while(i<this.Habitaciones.size()){
            if(this.Habitaciones.get(i).getOcupada()){
                int dias=this.Habitaciones.get(i).getHuespedes().getFechaEntrada().getCantDias(this.Habitaciones.get(i).getHuespedes().getFechaSalida());
                if(dias<30) {
                    ingreso = ingreso + dias * this.Habitaciones.get(i).getPrecioPorDia();
                }
                else{
                    int monto = dias*(this.Habitaciones.get(i).getPrecioPorDia());
                    ingreso = ingreso + monto - (monto / 4);
                }
            }
            i++;
        }
        return ingreso;
    }


    // Imprime el DNI de las personas cuyos dias de estadia superan los 30;
    public void personasEstadiaProlongada(){
        int i = 0;
        while(i<this.Huesped.size()){
            if(this.Huesped.get(i).getFechaEntrada().getCantDias(this.Huesped.get(i).getFechaSalida())>30){
                System.out.println(Huesped.get(i).getDNI());
            }
            i++;
        }
    }


    // Muestra el DNI de la persona titular de una determinada habitacion.
    public int getHuespedDNI(int numHab) {
        int i=0;
        while(i<Habitaciones.size()){
            if(numHab==Habitaciones.get(i).getNumero()){
                break;
            }
        }
        return Habitaciones.get(i).getHuespedes().getDNI();
    }


    // Retorna la cantidad de dinero que tiene que pagar cada persona que haya decidido quedarse en el hotel. Hace un loop y muestra la informacion de aquellas habitaciones que estan ocupadas.
    public void importeAPagar(){
        int i=0;
        while(i<this.Habitaciones.size()){
            if(this.Habitaciones.get(i).getOcupada()){
                System.out.println("Nombre: "+this.Habitaciones.get(i).getHuespedes().getNombre()+" "+this.Habitaciones.get(i).getHuespedes().getApellido()+". Importe a pagar: "+ this.Habitaciones.get(i).getPrecioPorDia()*this.Habitaciones.get(i).getHuespedes().getFechaEntrada().getCantDias(this.Habitaciones.get(i).getHuespedes().getFechaSalida()));
            }
            i++;
        }
    }



}

